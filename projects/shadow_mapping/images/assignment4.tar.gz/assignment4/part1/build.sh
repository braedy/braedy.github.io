#!/bin/bash

if [ -z "$ASSIGNMENT4_ROOT" ]
then
    echo "ASSIGNMENT4_ROOT is not set"
    exit 1
fi

export PART1_ROOT=$ASSIGNMENT4_ROOT/part1 && \

# Generate build script
cd $PART1_ROOT/build && \
if [ ! -d linux ]; then
    mkdir linux
fi
cd linux && \
cmake -DCMAKE_INSTALL_PREFIX=$PART1_ROOT ../ && \

# Build and install the program
make -j8 && \
make install && \

# Run the program
cd ../../bin && \
./part1