// Assignment 3, Part 1
//
// Modify this source file and the mesh.vert and mesh.frag shaders to
// implement the Blinn-Phong shading. Use your model viewer from
// Assignment 2 as starting point.
//

#include <iostream>
#include <stdlib.h>
#include <map>
#include <GL/glew.h>
#include <GL/glut.h>
//#include <GL/glfw.h>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/matrix_inverse.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <GL/glu.h>
#include <AntTweakBar.h>
#include <glm/glm.hpp>
#define RENDER_WIDTH 800.0
#define RENDER_HEIGHT 600.0
#define SHADOW_MAP_RATIO 2

// doing away with the helper classes
float width, height; // window size
float zoom = 1.0f;
bool onscreen = false;
bool cull = true;
float moirebias = 0.0005f;
float sampleLightFrustrum = 0.f;
float clear[3] {0.529f,0.804f,0.983f};

glm::vec3 l_eye = glm::vec3(32.f, 20.f, zoom);
glm::vec3 l_at = glm::vec3(2.f, 0.f, -10.f);
glm::vec3 l_up = glm::vec3(0.f, 1.f, 0.f);
glm::vec3 light_position = glm::vec3(3.f, 20.f, 0.f);
glm::vec3 light_direction = glm::vec3(0.f, 0.f, -5.f);
float light_rotation = 30.f; // Light movement circle radius
GLuint fboId; // id of framebuffer for rendering from light position
GLuint depthTexture; // height values

GLhandleARB shadowShader; // shader handler
GLuint shadowMapUniform;
std::string wasd = "hold WASD";

std::string getEnvVar(const std::string &name)
{
    char *value = getenv(name.c_str());
    if (value == NULL) {
        return std::string();
    }
    else {
        return std::string(value);
    }
}

// Returns the absolute path to the shader directory.
std::string shaderDir(void)
{
    std::string rootDir = getEnvVar("ASSIGNMENT4_ROOT");
    if (rootDir.empty()) {
        std::cout << "Error: ASSIGNMENT4_ROOT is not set." << std::endl;
        exit(EXIT_FAILURE);
    }
    return rootDir + "/part1/src/shaders/";
}

void initGLEW(void)
{
    GLenum status = glewInit();
    if (status != GLEW_OK) {
        std::cerr << "Error: " << glewGetErrorString(status) << std::endl;
        exit(EXIT_FAILURE);
    }
}

void displayOpenGLVersion(void)
{
    std::cout << "OpenGL version: " << glGetString(GL_VERSION) << std::endl;
}

// load shaders
GLhandleARB loadShader(char* filename, unsigned int type){
    FILE *pfile;
    GLhandleARB handle;
    const GLcharARB* files[1];

    // shader compilation variable
    GLint result; // compilation
    GLint errorLogLength;
    char* errorLogText;
    GLsizei actualErrorLogLength;

    char buffer[400000];
    memset(buffer, 0, 400000);

    pfile = fopen(filename, "rb");
    if(!pfile){
        printf("File not found: '%s'.\n", filename);
        exit(0);
    }

    fread(buffer,sizeof(char), 400000, pfile);
    fclose(pfile);

    handle = glCreateShaderObjectARB(type);
    if(!handle){
        printf("Failed creating shader object from file: %s.", filename);
        exit(0);
    }

    files[0] = (const GLcharARB*)buffer;
    glShaderSourceARB(handle, 1, files, NULL); //handle, no. of files, array of char* data
    glCompileShaderARB(handle);
    glGetObjectParameterivARB(handle, GL_OBJECT_COMPILE_STATUS_ARB, &result); // check compilation
    return handle;
}

void createShadowFBO(){
    int shadowMapWidth = width * SHADOW_MAP_RATIO;
    int shadowMapHeight = height * SHADOW_MAP_RATIO;

    GLenum FBOstatus;

    // texture depth component
    glGenTextures(1, &depthTexture);
    glBindTexture(GL_TEXTURE_2D, depthTexture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    // remove artifacts from edge of shadowmap
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, shadowMapWidth, shadowMapHeight, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_BYTE, 0);
   glBindTexture(GL_TEXTURE_2D, 0);
   // create FrameBufferObject
   glGenFramebuffersEXT(1, &fboId);
   glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, fboId);

   // bind no color
   glDrawBuffer(GL_NONE);
   glReadBuffer(GL_NONE);

   // attach texture to FBO depth attachment point
   glFramebufferTexture2DEXT(GL_FRAMEBUFFER_EXT, GL_DEPTH_ATTACHMENT_EXT, GL_TEXTURE_2D, depthTexture, 0);

   // check status
   FBOstatus = glCheckFramebufferStatusEXT(GL_FRAMEBUFFER_EXT);
   if(FBOstatus != GL_FRAMEBUFFER_COMPLETE_EXT) printf("GL_FRAMEBUFFER_COMPLETE_EXT failed, unable to use FBO\n");

   // swtich back to x11 framebuffer
   glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0);
   printf("Shadow Buffer Created\n");
}

void update(void){
    light_position = glm::vec3(light_rotation * cos(0.001 * glutGet(GLUT_ELAPSED_TIME)),20.0f, light_rotation * sin(0.001 * glutGet(GLUT_ELAPSED_TIME)));
}

void setTextureMatrix(void){
    static double modelView[16];
    static double projection[16];
    const GLdouble bias[16] = {
         0.5, 0.0, 0.0, 0.0,
         0.0, 0.5, 0.0, 0.0,
         0.0, 0.0, 0.5, 0.0,
         0.5, 0.5, 0.5, 1.0};

    glGetDoublev(GL_MODELVIEW_MATRIX, modelView);
    glGetDoublev(GL_PROJECTION_MATRIX, projection);
    glMatrixMode(GL_TEXTURE);
    glActiveTextureARB(GL_TEXTURE7);
    glLoadIdentity();
    glLoadMatrixd(bias);
    glMultMatrixd(projection);
    glMultMatrixd(modelView);
    glMatrixMode(GL_MODELVIEW);
}

void startTranslate(float x, float y, float z){
    glPushMatrix();
    glTranslatef(x,y,z);
    glMatrixMode(GL_TEXTURE);
    glActiveTextureARB(GL_TEXTURE7);
    glPushMatrix();
    glTranslatef(x,y,z);
}

void endTranslate(){
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
}

void defineMatrices(glm::vec3 eye, glm::vec3 at, glm::vec3 up)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45*zoom,width/height,10,40000);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(eye.x, eye.y, eye.z, at.x, at.y, at.z, up.x, up.y, up.z);
}

void draw(){

    glColor4f(0.42f, 0.5f, 0.15f, 1);
    glBegin(GL_QUADS);
    glVertex3f(-35,-2,-65);
    glVertex3f(-35,-2,15);
    glVertex3f(30,-2,15);
    glVertex3f(30,-2,-65);
    glEnd();

    glColor4f(0.54f,0.27f,0.27f,1);
    startTranslate(0,0,-16);
    glutSolidCube(4);
    endTranslate();
    glColor4f(0.0f,0.3f,0.0f,1);
    startTranslate(0,4,-16);
    glutSolidSphere(4, 200, 200);
    endTranslate();

    glColor4f(0.7f,0.4f,0.7f,1);
    startTranslate(-4,0,-6);
    glutSolidCube(4);
    endTranslate();
    glColor4f(0.5f,0.5f,0.5f,1);
    startTranslate(1,-2,-10);
    glutSolidCube(2);
    endTranslate();
}

void init(void)
{
    std::string vert_path = shaderDir() + "shadow.vert";
    std::string frag_path = shaderDir() + "shadow.frag";
    char *vertex_shader = &vert_path[0];
    char *fragment_shader = &frag_path[0];
    GLhandleARB vHandle, fHandle;
    vHandle = loadShader(vertex_shader, GL_VERTEX_SHADER);
    fHandle = loadShader(fragment_shader, GL_FRAGMENT_SHADER);
    shadowShader = glCreateProgramObjectARB();
    glAttachObjectARB(shadowShader, vHandle);
    glAttachObjectARB(shadowShader, fHandle);
    glLinkProgramARB(shadowShader);
    shadowMapUniform = glGetUniformLocationARB(shadowShader, "shadowMap");
}

void display(void)
{
    update();
    glClearColor(clear[0], clear[1], clear[2], 1.0);
    // render from light position to FBO
    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT,fboId); //offscreen
    glUseProgramObjectARB(0); //fixed pipeline
    glViewport(0,0,width * SHADOW_MAP_RATIO, height * SHADOW_MAP_RATIO);//handle resize
    glClear(GL_DEPTH_BUFFER_BIT); // clear previous frame values
    glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE); // only write to z-buffer
    defineMatrices(light_position, light_direction, l_up);
    if(cull){glCullFace(GL_FRONT);} // cull switching, rendering only backface to avoid self shadowing
    draw();
    setTextureMatrix(); // add bias
    glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, 0); // render from camera using FBO to generate shadows
    glViewport(0,0,width,height);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE); // enable color writes
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glUseProgramObjectARB(shadowShader);
    glUniform1iARB(shadowMapUniform, 7);
    glUniform1f(glGetUniformLocationARB(shadowShader,"bias"), moirebias);
    glUniform1f(glGetUniformLocationARB(shadowShader,"viewFrustum"), sampleLightFrustrum);
    glActiveTextureARB(GL_TEXTURE7);
    glBindTexture(GL_TEXTURE_2D,depthTexture);
    defineMatrices(l_eye, l_at, l_up);
    if(cull){glCullFace(GL_BACK);}
    draw();
    TwDraw();
   if(onscreen){ 
       glUseProgramObjectARB(0);
	     glMatrixMode(GL_PROJECTION);
	     glLoadIdentity();
	     glOrtho(0.5 * -width, 0.5 * width, 0.5 * -height, 0.5 * height,1,20);
	     glMatrixMode(GL_MODELVIEW);
	     glLoadIdentity();
	     glColor4f(1,1,1,1);
	     glActiveTextureARB(GL_TEXTURE0);
	     glBindTexture(GL_TEXTURE_2D,depthTexture);
	     glEnable(GL_TEXTURE_2D);
	     glTranslated(0,0,-1);
	     glBegin(GL_QUADS);
	     glTexCoord2d(0,0);glVertex3f(0, 0, 0);
	     glTexCoord2d(1,0);glVertex3f(0.5 * width, 0, 0);
	     glTexCoord2d(1,1);glVertex3f(0.5 * width, 0.5 * height, 0);
	     glTexCoord2d(0,1);glVertex3f(0, 0.5 * height, 0);
	     glEnd();
	     glDisable(GL_TEXTURE_2D);
   }
    glutSwapBuffers();
}

void reshape(int rwidth, int rheight)
{
    width = rwidth;
    height = rheight;
    glViewport(0, 0, width, height);
}

// MODIFY THIS FUNCTION
void keyboard(unsigned char key, int x, int y)
{
    // Define your keyboard shortcuts here
    printf("User pressed the %c key\n", key);
    glutPostRedisplay();
    switch(key)
    {
        case 'w': l_eye.z++; break;
        case 's': l_eye.z--; break;
        case 'a': l_eye.x--; break;
        case 'd': l_eye.x++; break;
    }
}

void mouseButtonPressed(int button, int x, int y)
{
    if(button == 3) zoom -= 0.05;
    if(button == 4) zoom += 0.05;
}


void mouse(int button, int state, int x, int y)
{
    if (state == GLUT_DOWN) {
        mouseButtonPressed(button, x, y);
    }
}

void mouseHandler(int button, int state,  int x, int y)
{
    if(!TwEventMouseButtonGLUT(button, state, x, y)) mouse(button, state, x, y);
}

void keyboardHandler(unsigned char key, int x, int y)
{
    if(!TwEventKeyboardGLUT(key, x, y)) keyboard(key, x, y);
}

int main(int argc, char** argv)
{
    TwBar *bar; // pointer to tweak bar

    glutInit(&argc, argv);
    width = RENDER_WIDTH;
    height = RENDER_HEIGHT;
    glutInitWindowSize(width, height);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_ALPHA | GLUT_DEPTH);
    glutCreateWindow("Shadow Mapping");
    initGLEW();
    createShadowFBO();
    init();
    displayOpenGLVersion();
    glEnable(GL_DEPTH_TEST);
    glClearColor(0,0,0,1.0f);
    glEnable(GL_CULL_FACE);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glutDisplayFunc(display);
    glutIdleFunc(display);
    glutReshapeFunc(&reshape);
    glutKeyboardFunc(&keyboardHandler);
    glutMouseFunc(&mouseHandler);

    TwInit(TW_OPENGL, NULL);
    TwWindowSize(width,height);
    bar = TwNewBar("Settings");
    TwDefine(" Settings size='200 270' color='40 43 42' valueswidth=fit");
    TwAddVarRO(bar, "move", TW_TYPE_STDSTRING, &wasd, " label='move'");
    TwAddVarRW(bar, "radius", TW_TYPE_FLOAT, &light_rotation, "min=0 max=100 step=10 group='Light rotation'");
    TwAddVarRW(bar, "cull faces", TW_TYPE_BOOLCPP, &cull, "group='Refine'");
    TwAddVarRW(bar, "moire bias", TW_TYPE_FLOAT, &moirebias, "min=0 max=0.01 step=0.0001 group='Refine'");
    TwAddVarRW(bar, "sample tolerance", TW_TYPE_FLOAT, &sampleLightFrustrum, "min=-40 max=0 step=5 group='Refine'");
    TwAddVarRW(bar, "depth buffer", TW_TYPE_BOOLCPP, &onscreen, "group='Display'");
    TwAddVarRW(bar, "zoom", TW_TYPE_FLOAT, &zoom, "min=0.5f max=20.0f step=0.25 keyIncr='[' keyDecr=']' group='Display'");
    TwAddVarRW(bar, "background", TW_TYPE_COLOR3F, &clear, "colormode='hls' group='Display'");

    glutMainLoop();
}
